import {
  require_react
} from "./chunk-J5MLPFOJ.js";
export default require_react();
//# sourceMappingURL=react.js.map
