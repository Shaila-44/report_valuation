import { FileText, Clock, CheckCircle, AlertCircle, Upload, FolderOpen } from 'lucide-react';
import { DashboardStats, ValuationReport } from '../types';

interface DashboardProps {
  stats: DashboardStats;
  recentReports: ValuationReport[];
  onNavigate: (page: string, reportId?: string) => void;
}

export default function Dashboard({ stats, recentReports, onNavigate }: DashboardProps) {
  const statCards = [
    { label: 'Total Reports', value: stats.totalReports, icon: <FileText size={24} />, color: 'bg-blue-500' },
    { label: 'Draft', value: stats.draftReports, icon: <Clock size={24} />, color: 'bg-amber-500' },
    { label: 'Under Review', value: stats.reviewReports, icon: <AlertCircle size={24} />, color: 'bg-orange-500' },
    { label: 'Approved', value: stats.approvedReports, icon: <CheckCircle size={24} />, color: 'bg-green-500' },
  ];



  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    }).format(date);
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-2">Overview of valuation reports and system activity</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statCards.map((card) => (
          <div key={card.label} className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition-all duration-300 group">
            <div className="flex items-center justify-between mb-4">
              <div className={`${card.color} text-white p-3 rounded-xl shadow-sm group-hover:scale-110 transition-transform duration-300`}>{card.icon}</div>
              <div className="text-3xl font-bold text-gray-900">{card.value}</div>
            </div>
            <p className="text-sm font-medium text-gray-500 group-hover:text-gray-700 transition-colors">{card.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <button
          onClick={() => onNavigate('upload')}
          className="bg-gradient-to-br from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-xl p-8 flex items-center gap-6 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-1 group relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -translate-y-16 translate-x-16 group-hover:scale-150 transition-transform duration-700" />

          <div className="bg-white/20 p-4 rounded-xl backdrop-blur-sm group-hover:bg-white/30 transition-colors">
            <Upload size={32} />
          </div>
          <div className="text-left relative z-10">
            <p className="font-bold text-xl mb-1">Upload New PDF</p>
            <p className="text-blue-100 text-sm">Start a new valuation report</p>
          </div>
        </button>

        <button
          onClick={() => onNavigate('files')}
          className="bg-white hover:bg-gray-50 border border-gray-200 hover:border-blue-200 rounded-xl p-8 flex items-center gap-6 transition-all shadow-sm hover:shadow-md group"
        >
          <div className="bg-gray-100 p-4 rounded-xl group-hover:bg-blue-50 transition-colors">
            <FolderOpen size={32} className="text-gray-600 group-hover:text-blue-600 transition-colors" />
          </div>
          <div className="text-left">
            <p className="font-bold text-xl text-gray-900 mb-1">View Files</p>
            <p className="text-gray-500 text-sm">Browse organized reports</p>
          </div>
        </button>

        <div className="bg-white border border-gray-200 rounded-xl p-8 shadow-sm flex items-center justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-blue-50 rounded-full blur-2xl -translate-y-8 translate-x-8" />

          <div>
            <p className="text-sm font-medium text-gray-500 mb-1">Recent Activity</p>
            <p className="text-4xl font-bold text-gray-900">{stats.recentUploads}</p>
            <p className="text-sm text-green-600 font-medium mt-2 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-green-500" />
              Uploads this week
            </p>
          </div>
          <div className="p-4 bg-blue-50 rounded-xl">
            <Clock size={32} className="text-blue-600" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-8 py-6 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
          <h2 className="text-lg font-bold text-gray-900">Recent Reports</h2>
          <button className="text-sm text-blue-600 hover:text-blue-700 font-medium hover:underline">View All</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50/50 border-b border-gray-100">
              <tr>
                <th className="px-8 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Customer</th>
                <th className="px-8 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Bank</th>
                <th className="px-8 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Property Type</th>
                <th className="px-8 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Location</th>
                <th className="px-8 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-8 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Updated</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {recentReports.map((report) => (
                <tr
                  key={report.id}
                  className="hover:bg-blue-50/50 cursor-pointer transition-colors group"
                  onClick={() => onNavigate('editor', report.id)}
                >
                  <td className="px-8 py-4 whitespace-nowrap">
                    <div className="text-sm font-semibold text-gray-900 group-hover:text-blue-700 transition-colors">{report.customerName}</div>
                  </td>
                  <td className="px-8 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-600 bg-gray-100 px-2 py-1 rounded inline-block">{report.bankName}</div>
                  </td>
                  <td className="px-8 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-600">{report.propertyType}</div>
                  </td>
                  <td className="px-8 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-600">{report.location}</div>
                  </td>
                  <td className="px-8 py-4 whitespace-nowrap">
                    <span
                      className={`px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full border ${report.status === 'approved' ? 'bg-green-50 text-green-700 border-green-200' :
                        report.status === 'review' ? 'bg-orange-50 text-orange-700 border-orange-200' :
                          'bg-amber-50 text-amber-700 border-amber-200'
                        }`}
                    >
                      {report.status.charAt(0).toUpperCase() + report.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-8 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(report.updatedAt)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
