import { useState, useMemo } from 'react';
import { FolderOpen, ArrowRight, Building2 } from 'lucide-react';
import { ProjectReport } from './types';
import { useQuery } from '@tanstack/react-query';
import { banksApi } from '../../apis/bank.api';
import { INDIAN_BANKS } from '../../data/indianBanks';

interface ProjectNameStepProps {
    projectName: string;
    setProjectName: (name: string) => void;
    bankName: string;
    setBankName: (name: string) => void;
    onNext: () => void;
    recentProjects: ProjectReport[];
}

export default function ProjectNameStep({
    projectName,
    setProjectName,
    bankName,
    setBankName,
    onNext,
    recentProjects
}: ProjectNameStepProps) {
    const [showBankSuggestions, setShowBankSuggestions] = useState(false);

    const { data: banks } = useQuery({
        queryKey: ['banks'],
        queryFn: banksApi.getBanks,
    });

    const handleProjectNameSubmit = () => {
        if (projectName.trim() && bankName.trim()) {
            onNext();
        }
    };

    const formatDate = (date: Date) => {
        return date.toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric'
        });
    };

    const suggestions = useMemo(() => {
        const normalizedInput = bankName.toLowerCase();
        if (!normalizedInput && !showBankSuggestions) return [];

        const dynamicNames = banks?.map(b => b.name) || [];

        // Use a Set for case-insensitive tracking, but preserve original casing from INDIAN_BANKS first
        const seen = new Set<string>();
        const uniqueNames: string[] = [];

        // Add static banks first
        INDIAN_BANKS.forEach(name => {
            const lower = name.toLowerCase();
            if (!seen.has(lower)) {
                seen.add(lower);
                uniqueNames.push(name);
            }
        });

        // Add dynamic banks if not present
        dynamicNames.forEach(name => {
            const lower = name.toLowerCase();
            if (!seen.has(lower)) {
                seen.add(lower); // assuming dynamic name casing is acceptable if unique
                uniqueNames.push(name);
            }
        });

        return uniqueNames
            .filter(name => name.toLowerCase().includes(normalizedInput))
            .sort();
    }, [banks, bankName, showBankSuggestions]);

    return (
        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8 max-w-2xl mx-auto overflow-hidden relative">
            {/* Background Decoration */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50 rounded-full blur-3xl -translate-y-32 translate-x-32 pointer-events-none" />

            <div className="text-center mb-10 relative z-10">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg transform rotate-3 hover:rotate-6 transition-transform">
                    <FolderOpen size={36} className="text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900 mb-2">Create New Report</h2>
                <p className="text-gray-500 text-lg">Enter details for your document analysis report</p>
            </div>

            <div className="space-y-6">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Bank Name *</label>
                    <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Building2 size={20} className="text-gray-400 group-focus-within:text-blue-500 transition-colors" />
                        </div>
                        <input
                            type="text"
                            value={bankName}
                            onChange={(e) => {
                                setBankName(e.target.value);
                                setShowBankSuggestions(true);
                            }}
                            onFocus={() => setShowBankSuggestions(true)}
                            onBlur={() => setTimeout(() => setShowBankSuggestions(false), 200)}
                            placeholder="e.g., HDFC Bank, SBI"
                            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-lg transition-all shadow-sm hover:border-gray-400"
                            autoFocus
                        />

                        {/* Custom Dropdown */}
                        {showBankSuggestions && (
                            <div className="absolute z-50 w-full mt-1 bg-white rounded-lg shadow-xl border border-gray-100 max-h-60 overflow-auto scrollbar-thin scrollbar-thumb-gray-200">
                                {suggestions.length > 0 ? (
                                    suggestions.map((bank, index) => (
                                        <div
                                            key={`${bank}-${index}`}
                                            className="px-4 py-3 hover:bg-blue-50 cursor-pointer text-gray-700 hover:text-blue-700 transition-colors border-b border-gray-50 last:border-0 flex items-center gap-3"
                                            onClick={() => {
                                                setBankName(bank);
                                                setShowBankSuggestions(false);
                                            }}
                                        >
                                            <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-500">
                                                <Building2 size={16} />
                                            </div>
                                            <span className="font-medium">{bank}</span>
                                        </div>
                                    ))
                                ) : (
                                    <div className="px-4 py-3 text-gray-400 italic text-sm">
                                        No matching banks found
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Report Name *</label>
                    <input
                        type="text"
                        value={projectName}
                        onChange={(e) => setProjectName(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleProjectNameSubmit()}
                        placeholder="e.g., Tamil Land Documents - January 2024"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-lg"
                    />
                </div>

                <button
                    onClick={handleProjectNameSubmit}
                    disabled={!projectName.trim() || !bankName.trim()}
                    className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 disabled:from-gray-300 disabled:to-gray-300 disabled:cursor-not-allowed text-white px-6 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-3 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                >
                    Continue to Upload
                    <ArrowRight size={24} />
                </button>
            </div>

            {recentProjects.length > 0 && (
                <div className="mt-10 pt-8 border-t border-gray-100 relative z-10">
                    <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Recent Reports</h3>
                    <div className="space-y-3">
                        {recentProjects.slice(0, 3).map((project) => (
                            <div
                                key={project.id}
                                className="group p-4 border border-gray-100 rounded-xl hover:border-blue-200 hover:bg-blue-50/50 transition-all cursor-pointer flex items-center justify-between"
                            >
                                <div>
                                    <p className="font-semibold text-gray-900 group-hover:text-blue-700 transition-colors">{project.name}</p>
                                    <p className="text-xs text-gray-500 mt-1">
                                        {formatDate(project.createdAt)} • {project.fileCount} {project.fileCount === 1 ? 'file' : 'files'}
                                    </p>
                                </div>
                                <div className="w-8 h-8 rounded-full bg-gray-50 group-hover:bg-white flex items-center justify-center transition-colors">
                                    <ArrowRight size={16} className="text-gray-400 group-hover:text-blue-600" />
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}
