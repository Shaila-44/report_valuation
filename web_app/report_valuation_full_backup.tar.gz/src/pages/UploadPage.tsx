import Upload from '../components/Upload';

export default function UploadPage() {
    return <Upload />;
}
